package com.fastutils;

import com.fastutils.mixin.MinecraftAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

public class FastUtilsClient implements ClientModInitializer {
    /** Клавиша открытия меню. Не регистрируется как KeyMapping, поэтому её нет в настройках управления. */
    private static final int MENU_KEY = GLFW.GLFW_KEY_X;

    private static final int AIM_KEY = GLFW.GLFW_KEY_Y;

    private boolean menuKeyWasDown = false;
    private boolean aimKeyWasDown = false;

    @Override
    public void onInitializeClient() {
        Config.load();
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(AimAssist::restore);
    }

    private void onTick(Minecraft client) {
        // --- Секретное меню на X (только когда нет открытых экранов, чтобы не срабатывать в чате) ---
        boolean down = GLFW.glfwGetKey(client.getWindow().handle(), MENU_KEY) == GLFW.GLFW_PRESS;
        if (down && !menuKeyWasDown && client.screen == null && client.player != null) {
            client.setScreen(new FastUtilsScreen());
        }
        menuKeyWasDown = down;

        boolean aimDown = GLFW.glfwGetKey(client.getWindow().handle(), AIM_KEY) == GLFW.GLFW_PRESS;
        if (aimDown && !aimKeyWasDown && client.screen == null && client.player != null) {
            client.setScreen(new AimScreen());
        }
        aimKeyWasDown = aimDown;

        AimAssist.tick(client);

        LocalPlayer player = client.player;
        if (player == null || client.screen != null) return;

        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();

        int cap = -1;
        if (Config.fastXp && (main.is(Items.EXPERIENCE_BOTTLE) || off.is(Items.EXPERIENCE_BOTTLE))) {
            cap = Config.fastXpInterval;
        } else if (Config.fastPlace && (main.getItem() instanceof BlockItem || off.getItem() instanceof BlockItem)) {
            cap = Config.fastPlaceInterval;
        }

        if (cap >= 0) {
            MinecraftAccessor acc = (MinecraftAccessor) client;
            if (acc.fastutils$getRightClickDelay() > cap) {
                acc.fastutils$setRightClickDelay(cap);
            }
        }
    }
}
