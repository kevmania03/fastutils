package com.fastutils;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Отдельное меню Aim Optimizer (клавиша Y). */
public class AimScreen extends Screen {
    private Button aimToggle;
    private Button aimStrength;

    public AimScreen() {
        super(Component.literal("Aim"));
    }

    @Override
    protected void init() {
        int w = 200;
        int x = this.width / 2 - w / 2;
        int y = this.height / 2 - 35;

        aimToggle = addRenderableWidget(Button.builder(Component.empty(), b -> {
            Config.aimAssist = !Config.aimAssist;
            refresh();
        }).bounds(x, y, w, 20).build());

        aimStrength = addRenderableWidget(Button.builder(Component.empty(), b -> {
            Config.aimStrength = Config.aimStrength % 4 + 1;
            refresh();
        }).bounds(x, y + 24, w, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose())
                .bounds(x, y + 58, w, 20).build());

        refresh();
    }

    private void refresh() {
        aimToggle.setMessage(Component.literal("Aim Optimizer: " + (Config.aimAssist ? "ВКЛ" : "ВЫКЛ")));
        aimStrength.setMessage(Component.literal("Замедление: " + (Config.aimStrength * 20) + "%"));
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }
}
