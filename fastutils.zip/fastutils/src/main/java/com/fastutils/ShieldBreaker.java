package com.fastutils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;

/**
 * Когда вы бьёте игрока, который держит блок щитом, мод перед ударом меняет слот на топор.
 * Режим ShieldBreaker: один удар топором. Режим Stun: два удара (второй через stunDelay тиков).
 * После ударов слот возвращается.
 */
public final class ShieldBreaker {
    private static int prevSlot = -1;
    private static Entity second = null;
    private static int delay = 0;
    private static int restoreDelay = 0;
    private static boolean busy = false;

    private ShieldBreaker() {
    }

    /** Вызывается миксином перед каждой атакой игрока по сущности. */
    public static void onAttack(Player attacker, Entity target) {
        if (busy) return;
        if (!Config.shieldBreak && !Config.stun) return;
        Minecraft mc = Minecraft.getInstance();
        if (attacker != mc.player) return;
        if (!(target instanceof Player victim) || victim == attacker || !victim.isBlocking()) return;

        Inventory inv = attacker.getInventory();
        int axe = findAxe(inv);
        if (axe < 0) return;

        int cur = getSlot(inv);
        if (cur != axe) {
            if (prevSlot < 0) prevSlot = cur;
            setSlot(inv, axe);
        }
        restoreDelay = 2;
        if (Config.stun) {
            second = target;
            delay = Config.stunDelay;
        }
    }

    public static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) {
            prevSlot = -1;
            second = null;
            return;
        }
        if (second != null) {
            if (--delay > 0) return;
            Entity t = second;
            second = null;
            if (t.isAlive() && p.distanceTo(t) <= 4.5F) {
                busy = true;
                try {
                    mc.gameMode.attack(p, t);
                    p.swing(InteractionHand.MAIN_HAND);
                } finally {
                    busy = false;
                }
            }
            restoreDelay = 2;
            return;
        }
        if (prevSlot >= 0 && --restoreDelay <= 0) {
            setSlot(p.getInventory(), prevSlot);
            prevSlot = -1;
        }
    }

    private static int findAxe(Inventory inv) {
        for (int i = 0; i < 9; i++) {
            if (inv.getItem(i).is(ItemTags.AXES)) return i;
        }
        return -1;
    }

    // Через рефлексию, чтобы не зависеть от того, метод это или поле в данной версии.
    private static int getSlot(Inventory inv) {
        try {
            return (Integer) Inventory.class.getMethod("getSelectedSlot").invoke(inv);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
        }
        try {
            return Inventory.class.getField("selected").getInt(inv);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
        }
        return 0;
    }

    private static void setSlot(Inventory inv, int slot) {
        try {
            Inventory.class.getMethod("setSelectedSlot", int.class).invoke(inv, slot);
            return;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
        }
        try {
            Inventory.class.getField("selected").setInt(inv, slot);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
        }
    }
}
