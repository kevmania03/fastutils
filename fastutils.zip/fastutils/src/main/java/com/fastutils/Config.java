package com.fastutils;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Простые настройки. Интервал — сколько тиков между использованиями (1 = каждый тик, 4 = как в ваниле). */
public final class Config {
    public static boolean fastPlace = true;
    public static int fastPlaceInterval = 1;
    public static boolean fastXp = true;
    public static int fastXpInterval = 1;
    /** Замедление мыши возле игрока. */
    public static boolean aimAssist = false;
    /** Сила замедления 1..4 (20%, 40%, 60%, 80%). */
    public static int aimStrength = 2;
    /** ShieldBreaker: при ударе по игроку со щитом свап на топор, 1 удар. */
    public static boolean shieldBreak = false;
    /** Stun: то же, но 2 удара подряд. */
    public static boolean stun = false;
    /** Задержка между ударами Stun, тиков (1..6). */
    public static int stunDelay = 2;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("fastutils.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (InputStream in = Files.newInputStream(f)) {
            Properties p = new Properties();
            p.load(in);
            fastPlace = Boolean.parseBoolean(p.getProperty("fastPlace", "true"));
            fastXp = Boolean.parseBoolean(p.getProperty("fastXp", "true"));
            fastPlaceInterval = clamp(parse(p.getProperty("fastPlaceInterval"), 1));
            fastXpInterval = clamp(parse(p.getProperty("fastXpInterval"), 1));
            aimAssist = Boolean.parseBoolean(p.getProperty("aimAssist", "false"));
            aimStrength = clamp(parse(p.getProperty("aimStrength"), 2));
            shieldBreak = Boolean.parseBoolean(p.getProperty("shieldBreak", "false"));
            stun = Boolean.parseBoolean(p.getProperty("stun", "false"));
            stunDelay = Math.max(1, Math.min(6, parse(p.getProperty("stunDelay"), 2)));
        } catch (IOException | RuntimeException ignored) {
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("fastPlace", Boolean.toString(fastPlace));
        p.setProperty("fastXp", Boolean.toString(fastXp));
        p.setProperty("fastPlaceInterval", Integer.toString(fastPlaceInterval));
        p.setProperty("fastXpInterval", Integer.toString(fastXpInterval));
        p.setProperty("aimAssist", Boolean.toString(aimAssist));
        p.setProperty("aimStrength", Integer.toString(aimStrength));
        p.setProperty("shieldBreak", Boolean.toString(shieldBreak));
        p.setProperty("stun", Boolean.toString(stun));
        p.setProperty("stunDelay", Integer.toString(stunDelay));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, null);
        } catch (IOException ignored) {
        }
    }

    private static int parse(String s, int def) {
        try {
            return Integer.parseInt(s);
        } catch (RuntimeException e) {
            return def;
        }
    }

    public static int clamp(int v) {
        return Math.max(1, Math.min(4, v));
    }
}
