package com.fastutils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Липкий прицел: когда прицел близко к другому игроку, чувствительность мыши
 * временно снижается. Сам прицел не двигается. Реальное значение чувствительности
 * запоминается и возвращается, когда игрока рядом с прицелом нет.
 */
public final class AimAssist {
    private static final double RANGE = 6.0;       // дальность, блоков
    private static final double EXTRA_DEG = 8.0;   // зона вокруг хитбокса, градусов

    private static Double original = null;
    private static double lastSet = -1;

    private AimAssist() {
    }

    public static void tick(Minecraft client) {
        if (client.options == null) return;
        OptionInstance<Double> opt = client.options.sensitivity();
        double cur = opt.get();

        // Если игрок сам поменял чувствительность, пока мы её занижали — принимаем новое значение.
        if (original != null && Math.abs(cur - lastSet) > 1e-9) {
            original = null;
        }

        double mult = 1.0;
        if (Config.aimAssist && client.player != null && client.level != null && client.screen == null) {
            mult = compute(client);
        }

        if (mult >= 0.999) {
            if (original != null) {
                opt.set(original);
                original = null;
            }
            return;
        }

        if (original == null) original = cur;
        opt.set(original * mult);
        lastSet = opt.get();
    }

    /** Вернуть настоящую чувствительность (при выходе из игры). */
    public static void restore(Minecraft client) {
        if (original != null && client.options != null) {
            client.options.sensitivity().set(original);
            original = null;
        }
    }

    private static double compute(Minecraft client) {
        Player self = client.player;
        Vec3 eye = self.getEyePosition();
        Vec3 look = self.getViewVector(1.0F);
        double reduction = 0.2 * Config.aimStrength;
        double best = 0.0; // 0..1, насколько близко прицел к цели

        for (Player other : client.level.players()) {
            if (other == self || other.isSpectator() || !other.isAlive()) continue;
            Vec3 d = other.getBoundingBox().getCenter().subtract(eye);
            double dist = d.length();
            if (dist < 0.5 || dist > RANGE) continue;

            double cos = Math.max(-1.0, Math.min(1.0, look.dot(d) / dist));
            double angle = Math.toDegrees(Math.acos(cos));
            double hitbox = Math.toDegrees(Math.atan(0.9 / dist));
            double outer = hitbox + EXTRA_DEG;
            if (angle >= outer) continue;

            double t = 1.0 - angle / outer;
            if (t > best) best = t;
        }
        return 1.0 - reduction * best;
    }
}
