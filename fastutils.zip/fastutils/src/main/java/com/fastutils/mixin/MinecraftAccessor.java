package com.fastutils.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(Minecraft.class)
public interface MinecraftAccessor {
    @Accessor("rightClickDelay")
    int fastutils$getRightClickDelay();

    @Accessor("rightClickDelay")
    void fastutils$setRightClickDelay(int value);
}
