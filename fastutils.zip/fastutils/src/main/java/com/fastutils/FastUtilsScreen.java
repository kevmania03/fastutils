package com.fastutils;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class FastUtilsScreen extends Screen {
    private Button placeToggle;
    private Button placeInterval;
    private Button xpToggle;
    private Button xpInterval;

    public FastUtilsScreen() {
        super(Component.literal("FastUtils"));
    }

    @Override
    protected void init() {
        int w = 200;
        int x = this.width / 2 - w / 2;
        int y = this.height / 2 - 55;

        placeToggle = addRenderableWidget(Button.builder(Component.empty(), b -> {
            Config.fastPlace = !Config.fastPlace;
            refresh();
        }).bounds(x, y, w, 20).build());

        placeInterval = addRenderableWidget(Button.builder(Component.empty(), b -> {
            Config.fastPlaceInterval = Config.fastPlaceInterval % 4 + 1;
            refresh();
        }).bounds(x, y + 24, w, 20).build());

        xpToggle = addRenderableWidget(Button.builder(Component.empty(), b -> {
            Config.fastXp = !Config.fastXp;
            refresh();
        }).bounds(x, y + 58, w, 20).build());

        xpInterval = addRenderableWidget(Button.builder(Component.empty(), b -> {
            Config.fastXpInterval = Config.fastXpInterval % 4 + 1;
            refresh();
        }).bounds(x, y + 82, w, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose())
                .bounds(x, y + 116, w, 20).build());

        refresh();
    }

    private void refresh() {
        placeToggle.setMessage(Component.literal("FastPlace: " + (Config.fastPlace ? "ВКЛ" : "ВЫКЛ")));
        placeInterval.setMessage(Component.literal("FastPlace — интервал: " + Config.fastPlaceInterval + " тик."));
        xpToggle.setMessage(Component.literal("FastXP: " + (Config.fastXp ? "ВКЛ" : "ВЫКЛ")));
        xpInterval.setMessage(Component.literal("FastXP — интервал: " + Config.fastXpInterval + " тик."));
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }
}
