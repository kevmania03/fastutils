package com.fastutils;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class FastUtilsScreen extends Screen {
    private Button placeToggle;
    private Button placeInterval;
    private Button xpToggle;
    private Button xpInterval;
    private Button shieldToggle;
    private Button stunToggle;
    private Button stunDelay;

    public FastUtilsScreen() {
        super(Component.literal("FastUtils"));
    }

    private Button add(int x, int y, int w, Runnable action) {
        return addRenderableWidget(Button.builder(Component.empty(), b -> {
            action.run();
            refresh();
        }).bounds(x, y, w, 20).build());
    }

    @Override
    protected void init() {
        int w = 200;
        int x = this.width / 2 - w / 2;
        int y = this.height / 2 - 105;

        placeToggle = add(x, y, w, () -> Config.fastPlace = !Config.fastPlace);
        placeInterval = add(x, y + 22, w, () -> Config.fastPlaceInterval = Config.fastPlaceInterval % 4 + 1);

        xpToggle = add(x, y + 50, w, () -> Config.fastXp = !Config.fastXp);
        xpInterval = add(x, y + 72, w, () -> Config.fastXpInterval = Config.fastXpInterval % 4 + 1);

        shieldToggle = add(x, y + 100, w, () -> {
            Config.shieldBreak = !Config.shieldBreak;
            if (Config.shieldBreak) Config.stun = false;
        });
        stunToggle = add(x, y + 122, w, () -> {
            Config.stun = !Config.stun;
            if (Config.stun) Config.shieldBreak = false;
        });
        stunDelay = add(x, y + 144, w, () -> Config.stunDelay = Config.stunDelay % 6 + 1);

        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose())
                .bounds(x, y + 172, w, 20).build());

        refresh();
    }

    private void refresh() {
        placeToggle.setMessage(Component.literal("FastPlace: " + (Config.fastPlace ? "ВКЛ" : "ВЫКЛ")));
        placeInterval.setMessage(Component.literal("FastPlace — интервал: " + Config.fastPlaceInterval + " тик."));
        xpToggle.setMessage(Component.literal("FastXP: " + (Config.fastXp ? "ВКЛ" : "ВЫКЛ")));
        xpInterval.setMessage(Component.literal("FastXP — интервал: " + Config.fastXpInterval + " тик."));
        shieldToggle.setMessage(Component.literal("ShieldBreaker (1 удар): " + (Config.shieldBreak ? "ВКЛ" : "ВЫКЛ")));
        stunToggle.setMessage(Component.literal("Stun (2 удара): " + (Config.stun ? "ВКЛ" : "ВЫКЛ")));
        stunDelay.setMessage(Component.literal("Stun — пауза между ударами: " + Config.stunDelay + " тик."));
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }
}
